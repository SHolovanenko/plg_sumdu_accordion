# plg_sumdu_accordion
Plugin to wrap content into the accordion tabs
